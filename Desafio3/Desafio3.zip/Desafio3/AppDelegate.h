//
//  AppDelegate.h
//  Desafio3
//
//  Created by Elisete Lourenco on 25/08/16.
//  Copyright © 2016 Elisete Lourenço. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

